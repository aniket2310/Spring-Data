package com.spring.orm;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.orm.dao.StudentDao;
import com.spring.orm.entities.Student;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
        StudentDao studentDao = context.getBean("studentDao", StudentDao.class);

        // BufferedReader in try-with-resources to ensure it gets closed
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            boolean go = true;
            while (go) {
                System.out.println("Press 1 : for add new Student ");
                System.out.println("Press 2 : for display all Students ");
                System.out.println("Press 3 : for get detail of a single Student ");
                System.out.println("Press 4 : for delete Student ");
                System.out.println("Press 5 : for update Student ");
                System.out.println("Press 6 : for EXIT ");

                try {
                    int input = Integer.parseInt(br.readLine());

                    switch (input) {
                        case 1: // insert the student
                            System.out.println("Enter the Student ID :");
                            int uid = Integer.parseInt(br.readLine());

                            System.out.println("Enter Student name : ");
                            String uName = br.readLine();

                            System.out.println("Enter the Student City : ");
                            String uCity = br.readLine();

                            Student student = new Student();
                            student.setStudentId(uid);
                            student.setStudentName(uName);
                            student.setStudentCity(uCity);

                            int insert = studentDao.insert(student);
                            System.out.println("Student inserted Successfully " + insert);
                            System.out.println("------------------------------------------------------------------------");
                            System.out.println();
                            break;
                        case 2: // display all students
                            System.out.println("_________________________________________________________");
                            List<Student> allstudents = studentDao.getAllStudent();
                            for (Student s : allstudents) {
                                System.out.println("ID   : " + s.getStudentId());
                                System.out.println("Name : " + s.getStudentName());
                                System.out.println("City : " + s.getStudentCity());
                                System.out.println("_________________________________________________________");
                            }
                            break;
                        case 3: // print single student
                            System.out.println("Enter the Student ID :");
                            int userid = Integer.parseInt(br.readLine());
                            Student st = studentDao.getStudent(userid);
                            System.out.println("ID   : " + st.getStudentId());
                            System.out.println("Name : " + st.getStudentName());
                            System.out.println("City : " + st.getStudentCity());
                            System.out.println("_________________________________________________________");
                            break;
                        case 4: // delete student
                            System.out.println("Enter the Student ID :");
                            int id = Integer.parseInt(br.readLine());
                            studentDao.deleteStudent(id);
                            System.out.println("Student deleted ");
                            break;
                        case 5: // update student
                            System.out.println("Enter the Student ID :");
                            int id1 = Integer.parseInt(br.readLine());

                            System.out.println("Enter Student name : ");
                            String uName1 = br.readLine();

                            System.out.println("Enter the Student City : ");
                            String uCity1 = br.readLine();

                            Student student3 = new Student();
                            student3.setStudentId(id1);
                            student3.setStudentName(uName1);
                            student3.setStudentCity(uCity1);
                            studentDao.updateStudent(student3);

                            System.out.println("Student details updated successfully");
                            break;
                        case 6:
                            go = false;
                            break;
                        default:
                            System.out.println("Invalid Input");
                            break;
                    }

                } catch (Exception e) {
                    System.out.println("Invalid Input");
                    e.printStackTrace();
                }
                System.out.println("Thank you for using my application");
                System.out.println("See you soon...!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
