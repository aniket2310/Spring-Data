package com.springcore.lifecycle;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Popcorn {

	private int price ;

	public Popcorn() {
		super();
	}
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Popcorn [price=" + price + "]";
	}	
	
	@PostConstruct
	public void start() {
		System.out.println("Popcorn making Start : init ");
	}
	
	@PreDestroy
	public void destroy() {
		System.out.println("Popcorn finished : destroy ");
	}
	
	
}
