package com.springcore.javaconfig;

import org.springframework.stereotype.Component;



public class Student {
	
	public void study() {
		this.samosa.display();
		System.out.println("student is reading book");
	}
	
	
	private Samosa samosa;
   
	

	public Student(Samosa samosa) {
		super();
		this.samosa = samosa;
	}

	public Samosa getSamosa() {
		return samosa;
	}

	public void setSamosa(Samosa samosa) {
		this.samosa = samosa;
	}

	@Override
	public String toString() {
		return "Student [samosa=" + samosa + "]";
	}
	
	
	
}
