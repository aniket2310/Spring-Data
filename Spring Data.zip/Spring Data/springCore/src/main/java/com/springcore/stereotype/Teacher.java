package com.springcore.stereotype;


//we can also use this to make scope prototype   @Scope("prototype")
public class Teacher {

	
	
}
