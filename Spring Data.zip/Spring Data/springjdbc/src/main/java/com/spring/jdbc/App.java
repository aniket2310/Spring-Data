package com.spring.jdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mysql.cj.protocol.x.ContinuousOutputStream;
import com.spring.jdbc.dao.StudentDao;
import com.spring.jdbc.dao.studentDaoImpl;
import com.spring.jdbc.entity.Student;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( " My Program Started " );
        
        //spring jdbc=> jdbcTemplate object
        
        ApplicationContext context = new AnnotationConfigApplicationContext(jdbcConfig.class);
        
        StudentDao studentDao =context.getBean("studentDao",StudentDao.class);
        
//        Student student = new Student();
//        student.setId(10);
//        student.setName("Andy herrrera");
//        student.setCity("Los Angeles");
//        
//        Student st = new Student();
//        st.setId(12);
//        st.setName("John Snow");
//        st.setCity("North ");
//        
//        int result = studentDao.insert(student);
//        int result1 = studentDao.insert(st);
//
//        System.out.println("student added :"+result);
//        System.out.println("student added :"+result1);

        
        
//        Student s = new Student();
//        s.setId(11);
//        s.setName("herculus");
//        s.setCity("America");
//        
//        
//int result = studentDao.change(s);
//System.out.println("data change "+result);
      
        
        
        
//        
//        Student student = new Student();
//        student.setId(456);
//        
//        int result = studentDao.delete(student);
//        System.out.println("record deleted"+result);
        
        
        
        
        
//    Student student =  studentDao.getStudent(10);
//        System.out.println(student);
//

        
        List<Student> students = studentDao.getAllStudent();
        for(Student s:students);
        System.out.print(" "+students);
    }
    
    
}
