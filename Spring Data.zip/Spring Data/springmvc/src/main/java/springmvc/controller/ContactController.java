package springmvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.tomcat.jni.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import springmvc.model.*;
import springmvc.service.UserService;

@Controller
public class ContactController {
	
	@Autowired
	private UserService userService;
	
	@ModelAttribute
	public void commonDataForModel(Model m) {
		
		m.addAttribute("Header","Learn Code with ANDY");
		m.addAttribute("Desc", "Home for Programmer");
		System.out.println("Adding Common data to model");
		
	}

	@RequestMapping("/contact")
	public String showForm(Model m) {
		
		return "contact";
		
	}
		@RequestMapping(path="/procressform",method=RequestMethod.POST)
		public String handleForm(@ModelAttribute springmvc.model.User user,Model model) {
		System.out.println(user);
		
		if(user.getUserName().isBlank()) {
			
			return "redirect:/one";
		}
		this.userService.createUser(user);
		model.addAttribute("msg","User Created Successfully...! ");
		return"success";
	}
	
}




/*
 * @RequestMapping(path="/procressform",method=RequestMethod.POST) public String
 * handleForm( @RequestParam("email")String userEmail,
 * 
 * @RequestParam("userName") String UserName,
 * 
 * @RequestParam("password")String Password, Model model) {
 * 
 * springmvc.model.User user = new springmvc.model.User();
 * user.setEmail(userEmail); user.setUserName(UserName);
 * user.setPassword(Password);
 * 
 * System.out.println(user);
 * 
 * model.addAttribute("user",user);
 * 
 * // System.out.println("The email is    :  "+userEmail); //
 * System.out.println("The UserName is : "+UserName); //
 * System.out.println("The Password is : "+Password); // //procressing of the
 * data is done from here .. // // model.addAttribute("name", UserName); //
 * model.addAttribute("email",userEmail); //
 * model.addAttribute("password",Password); return"success"; }
 * 
 * }
 */