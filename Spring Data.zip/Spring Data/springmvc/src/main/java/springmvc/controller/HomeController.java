package springmvc.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(path = "/first",method = RequestMethod.GET)
public class HomeController {
	@RequestMapping("/index")
	public String index(Model model) {
		System.out.println("this is index Controller");
		model.addAttribute("name", "Aniket Bodhe");
		model.addAttribute("ID", 51);
		
		List<String> friends= new ArrayList<String>();
		friends.add("ABC");
		friends.add("DEF");
		friends.add("GHI");
		friends.add("JKL");
		
		model.addAttribute("f",friends);
		
		return "index";
	}
	
	@RequestMapping("/about")
	public String about() {
		
		System.out.println("This is about Controller ");
		return "about";
	}
	
	@RequestMapping("/help")
	public ModelAndView help() {
		System.out.println("This is help Controller");
		
		//creating ModelAndView Object
		ModelAndView modelAndView = new ModelAndView();
		
		
		//setting the data
	    modelAndView.addObject("name","Sharad Shukla");
	    modelAndView.addObject("rollno",11249);
	   LocalDateTime now = LocalDateTime.now();
	    modelAndView.addObject("lTime",now);
	    
	    //marks
	    
	    List<Integer> list = new ArrayList<Integer>();
	    list.add(445);
	    list.add(255);
	    list.add(645);
	    list.add(522);
	    list.add(994);
	    list.add(479);
	    
	    modelAndView.addObject("marks",list);
	    
	    //setting the view Name
	    modelAndView.setViewName("help");
		return modelAndView;
	}

	
}
